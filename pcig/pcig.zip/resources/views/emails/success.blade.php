@extends('layouts.panel')

@section('content')
<div class="container bg-succcess border rounded-2 py-5 my-5">
    <h1 class="text-center text-success">Mail Sent</h1>
    <br>
    <center>
    <a href="/" class="btn bg-primary">back</a>
    </center>
    <br><br>
</div>    
@endsection