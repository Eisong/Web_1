

<?php $__env->startSection('content'); ?>
<div class="container-fluid position-relative p-0">
<div class="item"></div>
<img src="<?php echo e(asset('images/main/about.jpg')); ?>" class="d-block w-100" height="250px" alt="..."> 

<div class="container position-absolute top-50 start-0">
<h1 class="text-white text-center display-4"><a href="/" class="text-white">Home</a>/Subsidiary</h1>
</div>
</div>

<!--Details-->
<aside class="container p-5">                  
<div class="container">
<?php 
   echo $brand->b_detail 
?>  
</div>
</aside>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\htdocs\pcig\resources\views/brand.blade.php ENDPATH**/ ?>