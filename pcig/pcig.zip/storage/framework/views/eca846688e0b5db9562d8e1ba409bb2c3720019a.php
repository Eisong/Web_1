<!DOCTYPE html>
<html>
    <head>
    <title><?php echo e($mailData['title']); ?></title>
    </head>
    <body>
      <h1><?php echo e($mailData['title']); ?></h1>
      <p><?php echo e($mailData['body']); ?></p>
    </body>
    
</html><?php /**PATH C:\xamp\htdocs\pcig\resources\views/emails/company.blade.php ENDPATH**/ ?>