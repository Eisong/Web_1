

<?php $__env->startSection('content'); ?>
<div class="container-fluid position-relative p-0">
    <div class="item"></div>
    <img src="<?php echo e(asset('images/main/about.jpg')); ?>" class="d-block w-100" height="250px" alt="..."> 
    
    <div class="container position-absolute top-50 start-0">
    <h1 class="text-white text-center"><a href="/" class="text-white">Home</a>/Subsidiaries</h1>
    </div>
</div> 

<aside class="container p-5">
    <div class="row justify-content-center">
        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-6 col-md-3 col-lg-3 p-1 p-lg-4 p-md-2">
            <a href="/brand/<?php echo e($brand->id); ?>">
                <div class="container-fluid p-0 border rounded-2">
                    <div class="container bg-white py-3" style="height: 125px;">
                        <center>
                            <img src="<?php echo e($brand->b_logo == '' ? asset('images/default/brand.png') : asset('images/logos/'.$brand->b_logo)); ?>" class="img-fluid rounded-top" width="60%">
                       
                        </center>         
                    </div>
                     <div class="container-fluid py-2 bg-light rounded-bottom">
                        <h6 class="text-dark text-center"><strong><?php echo e($brand->b_name); ?></strong></h6>
                        <h6 class="fs-6 text-center text-secondary text-capitalize"><?php echo e($brand->category); ?></h6>
                   
                     </div>
                   </div>
            </a>  
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>

</aside>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\htdocs\pcig\resources\views/brands.blade.php ENDPATH**/ ?>