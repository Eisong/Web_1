

<?php $__env->startSection('content'); ?>
<div class="container bg-light border rounded-2 py-5 my-5">
    <h1 class="text-center">Mail Sent</h1>
    <br><br>
    <center>
    <a href="/" class="btn bg-primary">back</a>
    </center>
    <br><br>
</div>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\htdocs\pcig\resources\views/emails/success.blade.php ENDPATH**/ ?>